class student:
    def __init__(self):
        self._roll=101
a=student()
print(a._roll)