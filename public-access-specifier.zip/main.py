class student:
    def __init__(self,name):
        self.name=name
a=student("Madhu")
print(a.name)