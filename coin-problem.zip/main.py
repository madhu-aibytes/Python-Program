n=int(input())
five=n//5
two=n%5//2
one=n%5%2//1
tot=five+two+one
print(tot,five,two,one)