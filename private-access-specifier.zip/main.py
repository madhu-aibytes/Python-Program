class student:
    def __init__(self):
        self.__mark = 90
    def show_mark(self):
        print(self.__mark)
a = student()
a.show_mark()
#print(a.__mark)gives error