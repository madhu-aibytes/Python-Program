n = int(input())
mid = n // 2
for i in range(n):
    for j in range(n):
        if n % 2 == 1 and (i == mid or j == mid):
            print("0", end="")
        elif n % 2 == 0 and (i == mid or i == mid - 1 or j == mid or j == mid - 1):
            print("0", end="")
        else:
            print("1", end="")
    print()
