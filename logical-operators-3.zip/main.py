
print (5>2>1)
print (5>2<1)
print (5==5<1)
print (5==5<=1)