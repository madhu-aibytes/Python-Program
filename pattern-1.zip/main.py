size=int(input())
for i in range (size):
    for j in range (size):
        if i%2==0:
            print("1",end="")
        else:
            print("0",end="")
    print()